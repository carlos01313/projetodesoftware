package entidades;

public class Company extends TaxPayer {

    private int numberOfEmployees;

    public Company(String name, double anualIncome, int numberOfEmployees) {
        super(name, anualIncome);
        this.numberOfEmployees = numberOfEmployees;
    }

    public int getNumberOfEmployees() {
        return numberOfEmployees;
    }

    @Override
    
    public double tax() {
        double basicTax;
        if (numberOfEmployees > 10) {
            basicTax = getAnualIncome() * 0.14;
        }
        else {
            basicTax = getAnualIncome() *  0.14;
		}
		
		return numberOfEmployees;
		
	}

}

            		
